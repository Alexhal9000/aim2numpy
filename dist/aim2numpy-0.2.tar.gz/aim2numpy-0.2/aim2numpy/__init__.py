# aim2numpy/__init__.py
from .extract import extract
