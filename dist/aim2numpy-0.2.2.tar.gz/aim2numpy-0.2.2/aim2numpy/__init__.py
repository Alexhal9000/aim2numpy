# aim2numpy/__init__.py
from .extract import extract
from .extract import get_header_info